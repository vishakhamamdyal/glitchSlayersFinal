package com.payrollapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeePayrollManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeePayrollManagementSystemApplication.class, args);
	}

}
